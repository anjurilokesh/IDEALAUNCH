/* ============================================================
   IDEALAUNCH — AUTH LAYER
   Session-based auth using sessionStorage. No backend: this is a
   front-end demo, so "authentication" means validating input shape
   and holding a session object for the tab's lifetime.
   ============================================================ */

const SESSION_KEY = "ideaLaunch.session";
const SAVED_KEY = "ideaLaunch.saved";

/* ---------- session helpers ---------- */

function getSession() {
  const raw = sessionStorage.getItem(SESSION_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function setSession(user) {
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
}

function clearSession() {
  sessionStorage.removeItem(SESSION_KEY);
  sessionStorage.removeItem(SAVED_KEY);
}

function isLoggedIn() {
  return getSession() !== null;
}

/* Redirect away from any protected page if there's no session.
   Call this at the top of every protected page's script. */
function requireSession() {
  if (!isLoggedIn()) {
    window.location.href = "login.html";
  }
}

/* ---------- saved ideas (per session) ---------- */

function getSavedIds() {
  const raw = sessionStorage.getItem(SAVED_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function isSaved(ideaId) {
  return getSavedIds().includes(ideaId);
}

function toggleSaved(ideaId) {
  const saved = getSavedIds();
  const index = saved.indexOf(ideaId);
  if (index === -1) {
    saved.push(ideaId);
  } else {
    saved.splice(index, 1);
  }
  sessionStorage.setItem(SAVED_KEY, JSON.stringify(saved));
  return saved.includes(ideaId);
}

/* ---------- form validation ---------- */

function validateUsername(value) {
  if (!value.trim()) return "Callsign is required.";
  if (value.trim().length < 3) return "Callsign needs at least 3 characters.";
  if (!/^[a-zA-Z0-9_ ]+$/.test(value.trim())) {
    return "Use letters, numbers, spaces, or underscores only.";
  }
  return "";
}

function validatePassword(value) {
  if (!value) return "Passcode is required.";
  if (value.length < 6) return "Passcode needs at least 6 characters.";
  if (!/[a-zA-Z]/.test(value) || !/[0-9]/.test(value)) {
    return "Passcode needs at least one letter and one number.";
  }
  return "";
}

/* ---------- login form wiring ---------- */

function initLoginForm() {
  // Already logged in? Skip straight to the dashboard.
  if (isLoggedIn()) {
    window.location.href = "dashboard.html";
    return;
  }

  const form = document.getElementById("login-form");
  const usernameInput = document.getElementById("username");
  const passwordInput = document.getElementById("password");
  const usernameError = document.getElementById("username-error");
  const passwordError = document.getElementById("password-error");
  const formError = document.getElementById("form-error");

  usernameInput.addEventListener("input", () => {
    usernameError.textContent = "";
    usernameInput.removeAttribute("data-invalid");
  });
  passwordInput.addEventListener("input", () => {
    passwordError.textContent = "";
    passwordInput.removeAttribute("data-invalid");
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    formError.textContent = "";

    const usernameMsg = validateUsername(usernameInput.value);
    const passwordMsg = validatePassword(passwordInput.value);

    usernameError.textContent = usernameMsg;
    passwordError.textContent = passwordMsg;
    usernameInput.toggleAttribute("data-invalid", Boolean(usernameMsg));
    passwordInput.toggleAttribute("data-invalid", Boolean(passwordMsg));

    if (usernameMsg || passwordMsg) return;

    setSession({
      name: usernameInput.value.trim(),
      loginTime: new Date().toISOString()
    });

    window.location.href = "dashboard.html";
  });
}

/* ---------- shared nav / logout wiring ---------- */

function initNav() {
  const session = getSession();
  const nameEl = document.getElementById("nav-username");
  if (nameEl && session) nameEl.textContent = session.name;

  const logoutBtn = document.getElementById("logout-btn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      clearSession();
      window.location.href = "login.html";
    });
  }

  const currentPage = document.body.dataset.page;
  document.querySelectorAll("[data-nav-link]").forEach((link) => {
    if (link.dataset.navLink === currentPage) {
      link.setAttribute("aria-current", "page");
    }
  });
}
