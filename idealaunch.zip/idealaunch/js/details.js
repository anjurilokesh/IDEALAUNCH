/* ============================================================
   IDEALAUNCH — IDEA DETAILS PAGE
   Looks up a single idea by the ?id= query param using find().
   ============================================================ */

requireSession();
initNav();

const root = document.getElementById("details-root");
const params = new URLSearchParams(window.location.search);
const idea = findIdeaById(params.get("id"));

if (!idea) {
  const notFound = document.createElement("div");
  notFound.className = "hud-panel idea-not-found";
  notFound.innerHTML = `
    <h3>Signal not found</h3>
    <p>That idea ID doesn't exist in the current pool.</p>
    <a href="explore.html" class="btn-ghost">Back to Explore</a>
  `;
  root.appendChild(notFound);
} else {
  const saved = isSaved(idea.id);

  const wrap = document.createElement("div");
  wrap.className = "details-grid";
  wrap.innerHTML = `
    <section class="hud-panel details-main">
      <div class="idea-card__top">
        <span class="idea-card__id">${idea.id}</span>
        <span class="idea-card__stage ${stageClass(idea.stage)}">${idea.stage}</span>
      </div>
      <h2>${idea.title}</h2>
      <p class="tagline">${idea.tagline}</p>
      <div class="idea-card__tags">
        ${idea.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}
      </div>

      <h4>Overview</h4>
      <p>${idea.description}</p>

      <h4>Founder's note</h4>
      <p>${idea.founderNote}</p>
    </section>

    <aside>
      <div class="hud-panel">
        <button type="button" class="btn-save ${saved ? "is-saved" : ""}" id="details-save-btn" aria-pressed="${saved}">
          ${saved ? "★ Saved to your list" : "☆ Save this idea"}
        </button>
        <div class="field-row"><span>Category</span><span>${idea.category}</span></div>
        <div class="field-row"><span>Stage</span><span>${idea.stage}</span></div>
        <div class="field-row"><span>Est. market size</span><span>${idea.marketSize}</span></div>
        <div class="field-row"><span>Idea ID</span><span>${idea.id}</span></div>
      </div>
      <a href="explore.html?category=${encodeURIComponent(idea.category)}" class="btn-ghost">
        See more in ${idea.category} →
      </a>
    </aside>
  `;
  root.appendChild(wrap);

  document.getElementById("details-save-btn").addEventListener("click", (e) => {
    const nowSaved = toggleSaved(idea.id);
    e.currentTarget.classList.toggle("is-saved", nowSaved);
    e.currentTarget.setAttribute("aria-pressed", String(nowSaved));
    e.currentTarget.textContent = nowSaved ? "★ Saved to your list" : "☆ Save this idea";
  });
}
