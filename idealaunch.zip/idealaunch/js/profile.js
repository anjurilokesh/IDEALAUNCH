/* ============================================================
   IDEALAUNCH — PROFILE PAGE
   ============================================================ */

requireSession();
initNav();

const BIO_KEY = "ideaLaunch.bio";
const session = getSession();

document.getElementById("profile-name").textContent = session.name;
document.getElementById("avatar-initial").textContent = session.name.charAt(0).toUpperCase();
document.getElementById("profile-login-time").textContent = new Date(
  session.loginTime
).toLocaleTimeString();
document.getElementById("profile-saved-count").textContent = getSavedIds().length;

const bioInput = document.getElementById("bio-input");
bioInput.value = sessionStorage.getItem(BIO_KEY) || "";

document.getElementById("save-bio-btn").addEventListener("click", () => {
  sessionStorage.setItem(BIO_KEY, bioInput.value.trim());
  const note = document.getElementById("save-note");
  note.textContent = "Saved for this session.";
  setTimeout(() => (note.textContent = ""), 2500);
});
