/* ============================================================
   IDEALAUNCH — SHARED APP HELPERS
   Rendering and lookup helpers built with map / filter / find,
   shared by dashboard.js, explore.js, saved.js and details.js.
   ============================================================ */

function findIdeaById(id) {
  return IDEAS.find((idea) => idea.id === id);
}

function stageClass(stage) {
  return "stage-" + stage.toLowerCase();
}

/* Builds one HUD-style idea card as a DOM node. */
function buildIdeaCard(idea) {
  const saved = isSaved(idea.id);

  const card = document.createElement("article");
  card.className = "idea-card";
  card.dataset.id = idea.id;

  card.innerHTML = `
    <div class="idea-card__top">
      <span class="idea-card__id">${idea.id}</span>
      <span class="idea-card__stage ${stageClass(idea.stage)}">${idea.stage}</span>
    </div>
    <h3 class="idea-card__title">${idea.title}</h3>
    <p class="idea-card__tagline">${idea.tagline}</p>
    <div class="idea-card__tags">
      ${idea.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}
    </div>
    <div class="idea-card__bottom">
      <span class="idea-card__category">${idea.category}</span>
      <div class="idea-card__actions">
        <button type="button" class="btn-save ${saved ? "is-saved" : ""}" data-action="save" aria-pressed="${saved}">
          ${saved ? "★ Saved" : "☆ Save"}
        </button>
        <a class="btn-ghost" href="idea-details.html?id=${idea.id}">Open</a>
      </div>
    </div>
  `;

  card.querySelector('[data-action="save"]').addEventListener("click", (e) => {
    const nowSaved = toggleSaved(idea.id);
    e.currentTarget.classList.toggle("is-saved", nowSaved);
    e.currentTarget.setAttribute("aria-pressed", String(nowSaved));
    e.currentTarget.textContent = nowSaved ? "★ Saved" : "☆ Save";
    if (typeof onSaveToggled === "function") onSaveToggled(idea.id, nowSaved);
  });

  return card;
}

/* Renders a list of ideas into a grid container, or an empty state
   if the list is empty. `emptyMessage` is a two-line object
   { title, body } shown in the empty state panel. */
function renderIdeaGrid(container, ideas, emptyMessage) {
  container.innerHTML = "";

  if (ideas.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.innerHTML = `
      <div class="empty-state__glyph">◌</div>
      <h3>${emptyMessage.title}</h3>
      <p>${emptyMessage.body}</p>
    `;
    container.appendChild(empty);
    return;
  }

  const fragment = document.createDocumentFragment();
  ideas.forEach((idea) => fragment.appendChild(buildIdeaCard(idea)));
  container.appendChild(fragment);
}

/* Populates a <select> with categories using map(). */
function populateCategorySelect(selectEl) {
  const options = CATEGORIES.map((cat) => `<option value="${cat}">${cat}</option>`);
  selectEl.insertAdjacentHTML("beforeend", options.join(""));
}

/* Core filter used by Explore and Saved: text search + category. */
function filterIdeas(ideas, { query = "", category = "all" } = {}) {
  const q = query.trim().toLowerCase();

  return ideas.filter((idea) => {
    const matchesCategory = category === "all" || idea.category === category;
    if (!matchesCategory) return false;
    if (!q) return true;

    const haystack = [idea.title, idea.tagline, idea.description, ...idea.tags]
      .join(" ")
      .toLowerCase();
    return haystack.includes(q);
  });
}
