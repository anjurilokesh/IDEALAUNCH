/* ============================================================
   IDEALAUNCH — EXPLORE PAGE
   Search + category filtering over the full IDEAS array.
   ============================================================ */

requireSession();
initNav();

const searchInput = document.getElementById("search-input");
const categorySelect = document.getElementById("category-select");
const grid = document.getElementById("explore-grid");
const resultCount = document.getElementById("result-count");

populateCategorySelect(categorySelect);

// Restore filters from the URL, if Dashboard/Saved linked in with one.
const params = new URLSearchParams(window.location.search);
if (params.get("category")) categorySelect.value = params.get("category");
if (params.get("q")) searchInput.value = params.get("q");

function renderResults() {
  const filtered = filterIdeas(IDEAS, {
    query: searchInput.value,
    category: categorySelect.value
  });

  resultCount.textContent = `${filtered.length} of ${IDEAS.length} ideas shown`;

  renderIdeaGrid(grid, filtered, {
    title: "No matching signals",
    body: "Try a different keyword or switch categories."
  });
}

searchInput.addEventListener("input", renderResults);
categorySelect.addEventListener("change", renderResults);

renderResults();
