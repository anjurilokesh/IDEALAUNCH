/* ============================================================
   IDEALAUNCH — DATA LAYER
   Static dataset of startup ideas. In a real product this would
   come from an API; here it's an in-memory array of objects so
   the whole app can run as static HTML/CSS/JS.
   ============================================================ */

const IDEAS = [
  {
    id: "IL-001",
    title: "CropSignal",
    tagline: "Satellite crop-stress alerts for smallholder farms",
    category: "Sustainability",
    stage: "Prototype",
    marketSize: "$4.2B",
    tags: ["AgriTech", "Satellite Data", "Climate"],
    description:
      "CropSignal reads free public satellite imagery to flag drought and pest stress on small farm plots two to three weeks before damage is visible to the eye. Farmers get a plain-language SMS alert with a recommended action, no smartphone or app install required.",
    founderNote:
      "The hard part isn't the imagery, it's the last mile: turning a stress index into one sentence a farmer can act on in under a minute."
  },
  {
    id: "IL-002",
    title: "Ledgerly",
    tagline: "Bookkeeping that reconciles itself for solo founders",
    category: "FinTech",
    stage: "Growth",
    marketSize: "$11.6B",
    tags: ["Accounting", "SMB", "Automation"],
    description:
      "Ledgerly watches a founder's bank and card feeds, auto-categorizes spend, and reconciles invoices without a human touching a spreadsheet. It's built for the one-person business that can't justify a bookkeeper but still needs clean books at tax time.",
    founderNote:
      "Trust is the whole product. One miscategorized transaction and a user checks every line by hand forever after."
  },
  {
    id: "IL-003",
    title: "Recall",
    tagline: "Spaced-repetition study plans built from lecture recordings",
    category: "EdTech",
    stage: "Concept",
    marketSize: "$2.8B",
    tags: ["Learning Science", "Audio", "Students"],
    description:
      "Recall transcribes a lecture, extracts the testable claims, and schedules them into a spaced-repetition review queue automatically. Students stop making flashcards by hand and start reviewing the ten minutes before it's forgotten.",
    founderNote:
      "Transcription is commodity now. The differentiator is picking which sentences are actually worth a flashcard."
  },
  {
    id: "IL-004",
    title: "Triage",
    tagline: "Symptom-to-specialist routing for rural clinics",
    category: "HealthTech",
    stage: "Prototype",
    marketSize: "$6.7B",
    tags: ["Clinical Ops", "Telehealth", "Access"],
    description:
      "Triage helps front-desk staff at understaffed rural clinics route incoming patients to the right specialist on the first call, cutting the average three-transfer referral chain down to one. It runs as a decision tree, not a diagnosis tool.",
    founderNote:
      "Deliberately not diagnosing anything keeps the regulatory path sane and the trust bar achievable."
  },
  {
    id: "IL-005",
    title: "Offcut",
    tagline: "A marketplace for factory fabric scraps and remnants",
    category: "E-commerce",
    stage: "Growth",
    marketSize: "$3.1B",
    tags: ["Circular Economy", "Manufacturing", "Marketplace"],
    description:
      "Offcut connects garment factories sitting on tons of unsellable fabric remnants with small designers and hobbyists who buy in bulk by the kilogram. Factories turn waste-disposal cost into revenue; buyers get designer fabric at a fraction of retail.",
    founderNote:
      "Photographing a bin of scraps well enough to sell it online turned out to be its own small craft."
  },
  {
    id: "IL-006",
    title: "Fieldnote",
    tagline: "Voice-first inspection reports for site engineers",
    category: "AI",
    stage: "Prototype",
    marketSize: "$5.4B",
    tags: ["Construction", "Voice AI", "Field Ops"],
    description:
      "Fieldnote lets a site engineer walk a job site talking out loud and turns the recording into a structured inspection report with photos, defects, and timestamps auto-tagged to GPS location, ready to send before they've left the ladder.",
    founderNote:
      "Nobody wants to type on a phone wearing work gloves. Voice isn't a feature here, it's the entire interface."
  },
  {
    id: "IL-007",
    title: "Sparebed",
    tagline: "Short-notice overflow housing for hospital discharge patients",
    category: "HealthTech",
    stage: "Concept",
    marketSize: "$1.9B",
    tags: ["Care Coordination", "Housing", "Hospitals"],
    description:
      "Sparebed matches patients who are medically ready for discharge but have nowhere safe to recover with vetted short-term rooms nearby, cutting the bed-blocking that costs hospitals millions in delayed discharges every year.",
    founderNote:
      "This is a two-sided trust problem before it's a technology problem. The matching algorithm is the easy 10%."
  },
  {
    id: "IL-008",
    title: "Carryon",
    tagline: "Peer-to-peer luggage space for last-minute international shipping",
    category: "E-commerce",
    stage: "Concept",
    marketSize: "$2.3B",
    tags: ["Logistics", "Travel", "P2P"],
    description:
      "Carryon connects people with unused checked-baggage allowance on international flights to senders who need a small package delivered faster and cheaper than courier services, splitting the savings between traveler and sender.",
    founderNote:
      "Customs and liability are the whole game. The matching UI is the part everyone assumes is hard, and it isn't."
  },
  {
    id: "IL-009",
    title: "Gradient",
    tagline: "Automatic rubric-based grading for open-ended homework",
    category: "EdTech",
    stage: "Growth",
    marketSize: "$3.6B",
    tags: ["Teacher Tools", "AI", "K-12"],
    description:
      "Gradient reads a teacher's existing rubric and a stack of scanned student responses, then returns scored, annotated feedback in the teacher's own grading voice, giving back hours every week without replacing the teacher's judgment call.",
    founderNote:
      "Teachers didn't want grading automated away from them, they wanted the first 80% of it done for them to review."
  },
  {
    id: "IL-010",
    title: "Lowvolt",
    tagline: "Community solar micro-investing in $10 shares",
    category: "Sustainability",
    stage: "Prototype",
    marketSize: "$8.9B",
    tags: ["Clean Energy", "Micro-investing", "Community"],
    description:
      "Lowvolt lets residents who can't install rooftop solar buy $10 shares in a community solar farm being built nearby, then receive a monthly credit on their power bill proportional to their stake, tracked transparently on a simple dashboard.",
    founderNote:
      "The regulatory patchwork across utility territories is brutal. Pick one state, get it right, then expand."
  },
  {
    id: "IL-011",
    title: "Underwrite",
    tagline: "Instant micro-insurance for gig-economy equipment",
    category: "FinTech",
    stage: "Concept",
    marketSize: "$4.8B",
    tags: ["Insurance", "Gig Economy", "Risk"],
    description:
      "Underwrite issues per-shift insurance for the tools gig workers depend on, a delivery bike, a rideshare dashcam, a food cart, priced by the hour and purchased from a phone in under thirty seconds before a shift starts.",
    founderNote:
      "Pricing risk on assets with almost no claims history is the founding technical problem, not the checkout flow."
  },
  {
    id: "IL-012",
    title: "Notchwork",
    tagline: "AI pair-designer for furniture makers working from sketches",
    category: "AI",
    stage: "Concept",
    marketSize: "$2.1B",
    tags: ["Maker Tools", "Generative Design", "Woodworking"],
    description:
      "Notchwork turns a napkin sketch of a furniture piece into a cut list, joinery plan, and material estimate, tuned for the tools and stock sizes an independent maker actually has on hand rather than an industrial shop floor.",
    founderNote:
      "Generic CAD already exists. The wedge is respecting what a one-person shop can realistically cut and clamp."
  },
  {
    id: "IL-013",
    title: "Sidebar",
    tagline: "Turn-taking video calls for co-parents after separation",
    category: "Social",
    stage: "Prototype",
    marketSize: "$0.9B",
    tags: ["Family", "Scheduling", "Communication"],
    description:
      "Sidebar gives separated co-parents a shared, neutral space to schedule video calls with their kids, log custody handoffs, and message each other with a built-in cooldown that softens messages sent in anger before they're delivered.",
    founderNote:
      "The message cooldown feature came directly from a beta user asking us to stop her from sending 11pm texts."
  },
  {
    id: "IL-014",
    title: "Portside",
    tagline: "Real-time berth availability for small fishing fleets",
    category: "Sustainability",
    stage: "Concept",
    marketSize: "$1.4B",
    tags: ["Maritime", "IoT", "Logistics"],
    description:
      "Portside puts a cheap sensor on harbor berths so small fishing boats can see open dock space from the water and radio ahead, cutting the hours boats currently burn circling a harbor waiting for a spot to open up.",
    founderNote:
      "Harbors are run by a patchwork of local authorities. Winning one harbor master's trust is the whole first year."
  },
  {
    id: "IL-015",
    title: "Sortkit",
    tagline: "Drop-off recycling sorting guided by a phone camera",
    category: "Sustainability",
    stage: "Growth",
    marketSize: "$3.9B",
    tags: ["Recycling", "Computer Vision", "Consumer"],
    description:
      "Sortkit points a phone camera at a bag of mixed recyclables and tells the user exactly which municipal bin each item goes in, tuned to their specific city's sorting rules instead of a generic recycling symbol chart nobody follows correctly.",
    founderNote:
      "Every city's rules are different, so the moat is a boring database of local rules, not the computer vision."
  },
  {
    id: "IL-016",
    title: "Handoff",
    tagline: "Shift-change notes that actually transfer context, for nurses",
    category: "HealthTech",
    stage: "Prototype",
    marketSize: "$2.6B",
    tags: ["Nursing", "Workflow", "Patient Safety"],
    description:
      "Handoff replaces the whiteboard-and-memory shift handover between nurses with a structured, timestamped note per patient that surfaces exactly what changed since the last shift, cutting the errors that happen in the first hour of a new shift.",
    founderNote:
      "Nurses will abandon any tool that adds typing time during an already frantic handover window. Speed beats features."
  },
  {
    id: "IL-017",
    title: "Kerbside",
    tagline: "Dynamic pricing for curbside parking in small downtowns",
    category: "FinTech",
    stage: "Concept",
    marketSize: "$1.7B",
    tags: ["Urban Mobility", "Municipal", "Pricing"],
    description:
      "Kerbside adjusts curbside parking prices block-by-block through the day based on real occupancy, giving small-town main streets the kind of dynamic parking pricing that only big cities could previously afford to run.",
    founderNote:
      "Selling to a city council moves at government speed. Budget an 18-month sales cycle before revenue, not six."
  },
  {
    id: "IL-018",
    title: "Afterhours",
    tagline: "On-demand shared studio time for musicians between gigs",
    category: "Social",
    stage: "Concept",
    marketSize: "$1.1B",
    tags: ["Music", "Marketplace", "Creators"],
    description:
      "Afterhours lets independent musicians rent unused hours in professional recording studios overnight at a steep discount, filling a studio's dead hours while giving working musicians access to gear they could never book in daylight rates.",
    founderNote:
      "Studio owners cared more about liability and gear damage than about the discount. Insurance became the pitch."
  }
];

const CATEGORIES = [...new Set(IDEAS.map((idea) => idea.category))].sort();
