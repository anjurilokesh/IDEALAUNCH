/* ============================================================
   IDEALAUNCH — SAVED IDEAS PAGE
   Filters the master IDEAS array down to saved ids with find().
   ============================================================ */

requireSession();
initNav();

const grid = document.getElementById("saved-grid");
const resultCount = document.getElementById("result-count");

function renderSaved() {
  const savedIds = getSavedIds();
  const savedIdeas = savedIds
    .map((id) => findIdeaById(id))
    .filter((idea) => Boolean(idea));

  resultCount.textContent =
    savedIdeas.length === 0 ? "" : `${savedIdeas.length} idea(s) saved`;

  renderIdeaGrid(grid, savedIdeas, {
    title: "Nothing saved yet",
    body: "Head to Explore Ideas and star anything worth revisiting."
  });
}

// Called by app.js after a save/unsave click — re-render so an
// unsaved card disappears from this list immediately.
function onSaveToggled() {
  renderSaved();
}

renderSaved();
