/* ============================================================
   IDEALAUNCH — DASHBOARD PAGE
   ============================================================ */

requireSession();
initNav();

const session = getSession();
document.getElementById("welcome-name").textContent = session.name;

// Stats built with array methods over IDEAS / saved list.
document.getElementById("stat-total").textContent = IDEAS.length;
document.getElementById("stat-categories").textContent = CATEGORIES.length;
document.getElementById("stat-saved").textContent = getSavedIds().length;

const growthCount = IDEAS.filter((idea) => idea.stage === "Growth").length;
document.getElementById("stat-growth").textContent = growthCount;

// Show the 3 most recently added ideas (end of the array).
const recent = IDEAS.slice(-3).reverse();
renderIdeaGrid(document.getElementById("recent-grid"), recent, {
  title: "No signals yet",
  body: "Check back soon."
});
